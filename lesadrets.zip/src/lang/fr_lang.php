<?php

	define('ACCUEIL', 'ACCUEIL');
	define('MENUS', 'MENUS');
	define('RESERVATION_MAJ', 'RESERVATIONS');
	define('LE_RESTAURANT', 'Le Restaurant');
	define('RESTAURANT_ADRETS', 'Restaurant Les Adrets');
	define('LE_CHEF', 'LE CHEF');
	define('MENU', 'MENU');
	define('AUJOURDHUI', 'AUJOURD\'HUI');
	define('CARTE', 'CARTE');
	define('ENTREE', '- Entrée -');
	define('PLAT', '- Plat -');
	define('DESSERT','- Desserts -');
	define('PRIX', 'Prix');
	define('ADRESSE', 'Adresse');
	define('HORAIRE', 'Les horaires');
	define('OUVERT_LUNDI_VENDREDI', 'Ouvert du Lundi - Vendredi');
	define('MIDI', 'Midi');
	define('SOIR', 'Soir');
	define('FERMETURE', 'Fermeture en août et une semaine en hiver');
	define('ENTRE_NOEL_JOUR_AN', 'entre noel et jour de l\'an');
	define('COMMENT_ALLER', 'Comment y aller ?');
	define('TRANSPORT_COMMUN', 'En Transport en commun : arrêt ');
	define('EN_VOITURE', 'En voiture');
	define('TELEPHONE', 'Téléphone');
	define('RESERVATION', 'Réservation');
	define('DATE_HEURE', 'Date & Heure : ');
	define('NOMBRE_CONVIVE', 'Nombre de convives : ');
	define('COMMENTAIRES', 'Commentaires');
	define('SPECIFICATIONS', 'Des spécifications liés à la réservation ?');
	define('NOM', 'Nom');
	define('PRENOM', 'Prénom');
	define('MAIL', 'Mail');
	define('RESERVATION_PLUS_5PERSONNES', 'Pour les réservations de plus de cinq personnes, contactez nous par telephone.');
	define('ENVOYER_RESERVATION', 'Envoyer la réservation');
	define('COORDONNEE', 'Coordonnées');


?>











